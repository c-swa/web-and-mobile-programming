export interface Cards {
  id: number;
  name: string,
  icon: string,
  answer: string
}
