import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {

  // define list of items
  items= [];

  // Write code to push new item
  submitNewItem() {

  }

  // Write code to complete item
  completeItem() {

  }

  // Write code to delete item
  deleteItem() {

  }

}
